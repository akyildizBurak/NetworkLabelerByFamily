using Autodesk.AutoCAD.Runtime;
using System.Windows;

namespace NetworkLabeler
{
    public class NetworkLabelerCommand
    {
        [CommandMethod("NETWORKLABELER")]
        public void ShowNetworkLabeler()
        {
            try
            {
                DebugLogger.Log("Starting NetworkLabeler command");
                var window = new MainWindow();
                window.ShowDialog();
            }
            catch (System.Exception ex)
            {
                DebugLogger.LogError("Error in NetworkLabeler command", ex);
                MessageBox.Show($"Error: {ex.Message}", "NetworkLabeler Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
} 